#include<stdio.h>
#include "rsa_secrets.h"

enum message_type type;


int main(){

	type=a;
	struct test t;
	t.a=10;
	t.b=20;
	printf("%d, %d", t.a, t.b);

}
