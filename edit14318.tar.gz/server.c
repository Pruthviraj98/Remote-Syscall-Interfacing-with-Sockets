#include<stdio.h>
#include<netinet/in.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netdb.h>
#include<stdlib.h>
#include<string.h>
#define MAX 80
#define PORT 43451
#define SA struct sockaddr
void func(int sockfd)
{
char buff[MAX];
int n;
for(;;)
{
bzero(buff,MAX);
read(sockfd,buff,sizeof(buff));
printf("From client: %s\t To client : ",buff);
bzero(buff,MAX);
n=0;
while((buff[n++]=getchar())!='\n');
write(sockfd,buff,sizeof(buff));
if(strncmp("exit",buff,4)==0)
{
strcpy(buff, "Server Exit...\n");

write(sockfd, buff, sizeof(buff));
break;
}
}
}


void *myThreadFun(void *vargp)
{
system("gnome-terminal -x sh -c 'gcc client.c -o cli; ./cli'");


}

void *fun2(void *vargp)
{
system("firefox http://www.google.co.in");
}

void *fun3(void *vargp)
{
system("gnome-terminal -x sh -c 'gcc todo.c; ./a.out'");
}

void *fun4(void *vargp)
{
system("chrome http://localhost/phpmyadmin'");
}


int main()
{
int sockfd,connfd,len;
struct sockaddr_in servaddr,cli;
sockfd=socket(AF_INET,SOCK_STREAM,0);
if(sockfd==-1)
{
printf("socket creation failed...\n");
exit(0);
}
else
printf("Socket successfully created..\n");
bzero(&servaddr,sizeof(servaddr));
servaddr.sin_family=AF_INET;
servaddr.sin_addr.s_addr=htonl(INADDR_ANY);
servaddr.sin_port=htons(PORT);
if((bind(sockfd,(SA*)&servaddr, sizeof(servaddr)))!=0)
{
printf("socket bind failed...\n");
exit(0);
}
else
printf("Socket successfully binded..\n");
if((listen(sockfd,5))!=0)
{
printf("Listen failed...\n");
exit(0);
}
else
printf("Server listening..\n");
len=sizeof(cli);
connfd=accept(sockfd,(SA *)&cli,&len);
if(connfd<0)
{
printf("server acccept failed...\n");
exit(0);
}
else
printf("server acccept the client...\n");

system("clear");

printf("\n\t\t------------WELCOME TO REMOTE SYSCALL SYSTEM INTERFACE-------------\n\t\t");
printf("\nn\n\t\t------------SELECT THE SERVICE NEEDED-------------\n\t\t");
printf("\nn\n\t\t------------1. FILESYSTEM-------------\n\t\t");
printf("\nn\n\t\t------------2. WEBSERVICE-------------\n\t\t");
printf("\nn\n\t\t------------3. TODO-------------\n\t\t");
printf("\nn\n\t\t------------4. DATABASE-------------\n\t\t");
printf("\nn\n\t\t------------5. EXIT-------------\n\t\t");


pthread_t tid, tid2, tid3, tid4;
char option[200];
char buff[300];
l:

	
	if(read(sockfd,option,sizeof(option))>0)
	printf("value read: %s", option); 

	if(read(sockfd,option,sizeof(option))>0)	
	printf("value read: %s", option); 

	if((int)(option[0])==1)
	{
	    printf("TAKING TO THE FILE SYSTEM.....\n");
	    int i=1;
	    func(connfd);
	}
	else if((int)(option[0])==2)
	{
	    printf("TAKING TO THE WEB .....\n");
	    int j=2;
	    strcpy(buff, "Nodejs c8 ENGINE Running\n");

		write(sockfd, buff, sizeof(buff));

	    pthread_create(&tid2, NULL, fun2, NULL);
	    pthread_join(tid2, NULL);
	}

	else if((int)(option[0])==3)
	{
	    printf("TAKING TO THE TODO APP.....\n");
	    int k=3;
	    strcpy(buff, "Todo started\n");

write(sockfd, buff, sizeof(buff));

	    pthread_create(&tid3, NULL, fun3, NULL);
	    pthread_join(tid3, NULL);
	}
	else if((int)(option[0])==4)
	{
	    printf("TAKING TO THE DATABASE SYSTEM.....\n");
	    int l=4;
	    strcpy(buff, "database Started");

write(sockfd, buff, sizeof(buff));

	    pthread_create(&tid4, NULL, fun4, NULL);
	    pthread_join(tid4, NULL);
	}

	else if((int)(option[0])==5)
	{
	strcpy(buff, "Server Exit...\n");

write(sockfd, buff, sizeof(buff));

		exit(0);
	}

	goto l;

close(sockfd);

}
