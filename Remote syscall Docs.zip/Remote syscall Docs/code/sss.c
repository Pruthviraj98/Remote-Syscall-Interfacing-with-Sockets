#include<pthread.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<sys/types.h>          
#include<sys/socket.h>
#include<time.h>
#include<netinet/in.h>
#include "rsa_secrets_server.h"
#include<math.h>

enum message_type type;

void *fun2(void *vargp)
{
    //spawn a new terminal 
	printf("inside func2");
	system("http-server -p 2400");
	sleep(1);
	return NULL;
    //start nodejs server
}

void *fun3(void *vargp)
{
    //spawn a new terminal 
	printf("starting xampp");
	system("./xampp -p 2400");
	sleep(1);
	return NULL;
    //start XAMPP server
}

void *fun4(void *vargp)
{
    //spawn a new terminal 
	printf("starting mysql in xampp");
	system("./xampp -p 2400");
	sleep(1);
	return NULL;
    //start XAMPP server
}


int main(int argc, char* argv[]){
	printf("argv[0] %s\n", argv[0]);
	pthread_t tid2, tid3, tid4;
	int sd2=atoi(argv[0]), bytes=0;

	char buffer[256];

	struct message m;
	handshake *fhs; //handshake pointer for recv the Init numbers

	printf("Exchanging the Public Keys....\n");
	type= RSAKEY;

	m.type=type;
		
	keys k; k.N= n; k.PHI= phi;

	memcpy((void*)m.payload, (void*)&k, sizeof(k));	
	memcpy(buffer, (void*)&m, sizeof(m));	

	if((bytes= send(sd2, buffer, 36, 0))>0);

//Read MSG from Client
    double e = 2;
    while (e < phi)
    {
        // e must be co-prime to phi and
        // smaller than phi.
        if (gcd(e, phi)==1)
            break;
        else
            e++;
    }
    int constant = 2;  // A constant value
    double d = (1 + (constant*phi))/e;
 

	if((bytes= recv(sd2, (char*)&m, sizeof(m), 0))>0){
			encDecMsg* MSG=(encDecMsg*)m.payload;
		
			printf("m.size 2 m.payload %s bytes %d\n", m.payload, bytes);
			type=MSG_TYPE;
			int i;
			for(i=0;i<2;i++){
				printf("num at %d = %d\n",i, MSG->cmd[i]);
				printf("DECRYPTED msg at %d = %lf\n\n",i, fmod(pow((double)(MSG->cmd[i]), d), n)+97);
				}				
		
		}
	char readbuf[80]; int by;
	strcpy(buffer, "INIT Interfacing View");
	if((bytes= send(sd2, buffer, 256, 0))>0) printf("INIT interfacing bytes %d", bytes);

	if(bytes= recv(sd2, buffer, 256, 0)) 	
		printf("\nClient: %s bytes %d \n", buffer, bytes);

	strcpy(buffer, "mutual_handshake");
	if(send(sd2, buffer, sizeof(buffer), 0)>0)
			;	

	l:
		if(recv(sd2, buffer, sizeof(buffer), 0)>0)
			printf("\nClient: %s", buffer);	
	
	switch(buffer[0]){
	
	case '1':

x:	

	by=recv(sd2, buffer, sizeof(buffer), 0);
	printf("by %d", by);
	printf("\nClient: %s", buffer);	
	if(by==0)
		goto l;

	if(!strcmp(buffer, "end")){
	    strcpy(buffer, "Stopping Terminal Binning....\n");
            if(send(sd2, buffer, sizeof(buffer), 0)>0)
				break;
	}



//to execute and store the console o/p into the file and retrive it back to a string to send that string buffer to the client.	
	FILE *pipein_fp;
	if((pipein_fp=popen(buffer,"r"))==NULL)
	{
	perror("popen");
	exit(1);
	}
	strcpy(buffer,"");
	while(fgets(readbuf, 80, pipein_fp))
		strcat(buffer, readbuf);
	pclose(pipein_fp);

	if(send(sd2, buffer, 200, 0)>0)
			;
// posix command MSG_SIGNAL is for preventeing the server stop abruptly just after invoking send(), but proper place to recieve this command has to be set in the client side.

	goto x;

        break;	
			
		case '2': 
 	        strcpy(buffer, "Nodejs c8 Static File ENGINE Running....\n");
 
		if(strlen(buffer)>0)
			if(send(sd2, buffer, 256, 0)>0);
	
		pthread_create(&tid2, NULL, fun2, NULL);
        	pthread_join(tid2, NULL);			
                break;

		case '3':

		strcpy(buffer, "TODO APPlication Loading.....\n");
		if(strlen(buffer)>0)
			if(send(sd2, buffer, 256, 0)>0);
		pthread_create(&tid3, NULL, fun3, NULL);
        	pthread_join(tid3, NULL);			

	        break;

		case '4':

	        strcpy(buffer, "Starting mySQL Service......");
		if(strlen(buffer)>0)
			if(send(sd2, buffer, 256, 0)>0)
				;	
		pthread_create(&tid4, NULL, fun4, NULL);
        	pthread_join(tid4, NULL);			

                break;

		case '5':
    strcpy(buffer, "GDropbox Link-Post Running...\n");

		if(strlen(buffer)>0)
			if(send(sd2, buffer, sizeof(buffer), 0)>0)
				;

                break;	

	case '6':
	    strcpy(buffer, "Mailbox Booting......\n");
		if(strlen(buffer)>0)
			if(send(sd2, buffer, 256, 0)>0)
				;
                break;	
	 
        case '7':
	    strcpy(buffer, "XAMPP server running...\n");
		if(strlen(buffer)>0)
			if(send(sd2, buffer, 256, 0)>0)
				;

		pthread_create(&tid3, NULL, fun3, NULL);
        	pthread_join(tid3, NULL);			
                break;	

         case '8':
	    strcpy(buffer, "Git Server Listening....\n");
x1:	

	by=recv(sd2, buffer, sizeof(buffer), 0);
	if(!strcmp(buffer, "end")){
	    strcpy(buffer, "Stopping GIT....\n");
            if(send(sd2, buffer, 256, 0)>0)
				break;
	}


	printf("\nClient: %s", buffer);	
	if(by==0)
		goto l;
//to execute and store the console o/p into the file and retrive it back to a string to send that string buffer to the client.	
	if((pipein_fp=popen(buffer,"r"))==NULL)
	{
	perror("popen");
	exit(1);
	}
	strcpy(buffer,"");
	while(fgets(readbuf, 80, pipein_fp))
		strcat(buffer, readbuf);
	pclose(pipein_fp);

	if(send(sd2, buffer, 256, 0)>0)
			;
// posix command MSG_SIGNAL is for preventeing the server stop abruptly just after invoking send(), but proper place to recieve this command has to be set in the client side.

	goto x1;

               break;	

           case '9':
	    strcpy(buffer, "File Editor Service being Ported....\n");
		if(strlen(buffer)>0)
			if(send(sd2, buffer, 256, 0)>0)
				;
                break;	
	} 

	goto l;

	close(sd2);	
	return 1;

}
