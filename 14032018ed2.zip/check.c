#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
int main()
{
char a[100];
scanf("%s", a);
if((int)(a[0])<3)
{
printf("%s",a);
}
else
{
int x=atoi(a);
printf("%d",x);
}
}
